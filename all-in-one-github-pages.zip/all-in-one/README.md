# All In One

An installable web app for **every age**. It includes quick games and quizzes, a learning hub, a drawing studio, safe science activities, daily challenges, and locally saved progress.

## Choose your level
The home screen offers three challenge levels:
- **Starter** — easier questions
- **Explorer** — medium questions
- **Expert** — advanced questions

Choose the level that feels right; age is not used to restrict access. The selected level is saved on the device.

## Run it
Open `index.html` in a browser for a basic preview. For installable PWA features, publish the files on an HTTPS static host such as GitHub Pages.

## Publish free with GitHub Pages
1. Create a public GitHub repository.
2. Upload the contents of this folder (not the folder itself).
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
5. Open the published URL.

## Install
- Android: open the published site in Chrome and choose **Install app** or **Add to Home screen**.
- iPhone/iPad: open it in Safari, tap Share, then **Add to Home Screen**.
- Computer: in Chrome or Edge, use the install icon in the address bar or the browser menu.

## Notes
- Progress and level preference are stored locally on the device.
- This starter version does not include accounts, cloud sync, multiplayer, or app-store publishing.
- For younger users, an adult should supervise online access and hands-on science activities.
